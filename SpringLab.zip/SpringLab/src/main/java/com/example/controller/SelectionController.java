package com.example.controller;

import com.example.model.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SelectionController {

    @GetMapping("/selection")
    public String showSelection(Model model){
        User u = new User();
        u.fullName = "Lima";
        u.email = "lima@example.com";

        model.addAttribute("user", u);

        return "selection";
    }
}
