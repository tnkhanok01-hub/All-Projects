package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class VariableController {

    @GetMapping("/variables")
    public String showVars(Model model){
        model.addAttribute("name", "Tahiya");
        model.addAttribute("age", 21);
        return "variables";
    }
}
