package com.example.model;

public class User {
    public String fullName;
    public String email;
}
