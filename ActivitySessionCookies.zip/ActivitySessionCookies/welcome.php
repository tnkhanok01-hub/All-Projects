<?php
	session_start();
	echo "Welcome " . $_SESSION['email'];
	
?>
	<form name="" action="" method="post">
	<input type="Submit" value="Go To Next Page" name="next">
	</form>

<?php
	if(isset($_POST['next']))
	{
	$_SESSION['email'];
	header("location: second.php");
	}

	//session_destroy();
?>