package com.example.timetable_di

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
