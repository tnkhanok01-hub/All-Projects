import 'package:flutter/material.dart';
import 'package:get_it/get_it.dart';

// Service
class TimetableService {
  List<String> getTodaySchedule() {
    return [
      "8:00 AM - Data Structures",
      "10:00 AM - Software Engineering",
      "2:00 PM - Mobile Programming"
    ];
  }
}

// Controller
class TimetableController {
  final TimetableService service;

  // Constructor DI
  TimetableController(this.service);

  List<String> getSchedule() {
    return service.getTodaySchedule();
  }
}

class TimetableProvider extends InheritedWidget {
  final TimetableService service;

  const TimetableProvider({
    Key? key,
    required this.service,
    required Widget child,
  }) : super(key: key, child: child);

  static TimetableProvider of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<TimetableProvider>()!;
  }

  @override
  bool updateShouldNotify(TimetableProvider oldWidget) {
    return service != oldWidget.service;
  }
}

final getIt = GetIt.instance;

void setup() {
  getIt.registerSingleton<TimetableService>(TimetableService());
}

void main() {
  setup();
  runApp(MyApp());
}
// UI
class MyApp extends StatelessWidget {
  final service = getIt<TimetableService>();

  @override
  Widget build(BuildContext context) {
    final schedule = service.getTodaySchedule();

    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text("Today's Timetable")),
        body: ListView(
          children: schedule
              .map((e) => ListTile(title: Text(e)))
              .toList(),
        ),
      ),
    );
  }
}